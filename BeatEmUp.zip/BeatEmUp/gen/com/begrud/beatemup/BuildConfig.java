/** Automatically generated file. DO NOT MODIFY */
package com.begrud.beatemup;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}