/**
 * 
 */
/**
 * @author simonkenny
 *
 */
package com.begrud.beatemup.animation;