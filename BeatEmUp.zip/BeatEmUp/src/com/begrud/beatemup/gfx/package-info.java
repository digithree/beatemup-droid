/**
 * @author Michael Sherry
 *
 */
package com.begrud.beatemup.gfx;